Future Engineers NASA TechRise Student Challenge

World View Stratollite Arduino software

In this folder you will find demo code and a library for reading World View Stratollite telemetry 
from the TechRise Flight Simulator or World View flight control unit. The Arduino code has been 
written for use on a Metro M4 Express microcontroller but should be easily portable to other 
microcontrollers.

   m4-worldview-demo.ino - Arduino demo sketch
   TRSim_Worldview.h     - Header file for the TechRise World View Stratollite Simulator library
   TRSim_Worldview.cpp   - Library code for the TechRise World View Stratollite Simulator library

About the Demo
This is a very simple demo which reads World View Stratollite formatted data from the serial port. 
Wait, there are two serial ports! One serial port is the one that the Arduino app uses, and if you 
open the serial monitor in the Arduino app you'll be able to see output from the microcontroller. 
The other serial port is the output port from the Simulator; it's the one that you select when you 
press the serial button in the lower left of the Simulator web app. So data flows from the Simulator, 
to the microcontroller. The microcontroller processes the data and prints output via the other serial 
port to the serial monitor in the Arduino app. Easy!

Installing the Library
To make use of these files, first copy the library to where you store Arduino libraries.
For example, on Windows, they are typically stored in the user directory under 
Documents/Arduino/libraries. So if your username is mrfoo, you might find them in the
directory C:\Users\mrfoo\Documents\Arduino\libraries.
Create a directory there with the name of the library: TRSim_Worldview
Copy both the .h and .cpp files to this directory.
Congratulations, your library is installed!

Installing the Demo Sketch
Copying the demo to your system is just as easy. Just create a directory in the traditional
Arduino project location with the name of this demo: m4-worldview-demo.
For example, on Windows, you might put that at C:\Users\mrfoo\Documents\Arduino\m4-worldview-demo.
Copy the .ino sketch to this directory.
Now, when you run the Arduino app, you can select File/Open and choose the .ino file to open 
the sketch. Hit Verify/Upload to compile and execute on your microcontroller.

About the Library
If you examine the library you'll find the inner loop of the code, in update(), reads data
from the serial buffer and writes it to a ring buffer. Each time it detects a full telemetry
packet in the ring buffer, the packet is copied to a dedicated location and _new_data is set to
True. When the application calls getData(), it retrieves this packet and the library clears the 
_new_data flag. If update() is not called frequently enough, incoming data packets can write over 
the top of previous ones. So if you want to get all the telemetry, try to do just a small amount 
of processing on the microcontroller! Included in the library is an array of helper functions to 
retrieve particular data fields of the most recent data packet. Keep in mind however, that calling 
many of these functions for each packet will also slow down the microcontroller and possibly result
in missing incoming telemetry. Dealing with real-time data is tricky... use the Simulator to
help optimize your application's performance before the day of flight.

Have fun, and good luck!
